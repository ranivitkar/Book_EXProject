package com.bxw.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bxw.entities.Category;
import com.bxw.model.CategoryDTO;

import com.bxw.service.CategoryService;
import com.bxw.utility.CategoryConverter;

@RestController
public class CategoryController {
	@Autowired
	CategoryService categoryService;
	
	@Autowired 
	CategoryConverter categoryConverter;
	
	@PostMapping("/api/createCategory")
	ResponseEntity<CategoryDTO> createCategory(@RequestBody CategoryDTO categoryDto)
	{
		final Category category=categoryConverter.convertToCategoryEntity(categoryDto);
		return new ResponseEntity<CategoryDTO> (categoryService.createCategory(category),HttpStatus.CREATED);
	}
	
	
	@GetMapping("/api/getAllCategory")
	List<CategoryDTO> getAllCategory()
	{
		return categoryService.getAllCategory();
	}
	
	
	@GetMapping("/api/getCategoryByID/{categoryId}")
	CategoryDTO getCategoryById(@PathVariable("categoryId") int id)
	{
		return categoryService.getCategoryById(id);
	}
	
	
	@DeleteMapping("/api/deleteCategory/{categoryId}")
	String deleteCategoryById(@PathVariable("categoryId")int id)
	{
		return categoryService.deleteCategoryById(id);
	}


	@PutMapping("/api/updateCategory/{categoryId}")
	CategoryDTO updateCategory(@PathVariable("categoryId")int id,@RequestBody Category category)
	{
		return categoryService.updateCategory(id, category);
	}
}
