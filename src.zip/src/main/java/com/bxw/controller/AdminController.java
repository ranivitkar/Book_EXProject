package com.bxw.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bxw.entities.Admin;
import com.bxw.model.AdminDTO;
import com.bxw.service.AdminService;
import com.bxw.utility.AdminConverter;

@RestController
public class AdminController {
	@Autowired
	AdminService adminService;
	
	@Autowired
	AdminConverter adminConverter;
	
	@PostMapping("api/createAdmin")
	ResponseEntity<AdminDTO> createAdmin(@RequestBody AdminDTO adminDto)
	{
		final Admin admin=adminConverter.convertToAdminEntity(adminDto);
		return new ResponseEntity<AdminDTO>(adminService.createAdmin(admin),HttpStatus.CREATED);
	}	
	@GetMapping("/api/getAllAdmin")
	List<AdminDTO> getAllAdmin()
	{
		return adminService.getAllAdmin();
	}
	
	@GetMapping("/api/getAdminId/{adminId}")
	AdminDTO getAdminById(@PathVariable("adminId") int id)
	{
		return adminService.getAdminById(id);
	}
	
	@DeleteMapping("/api/deleteAdmin/{adminId}")
	String deleteAdminByID(@PathVariable("adminId")int id)
	{
		return adminService.deleteAdminById(id);
	}
	
	@PutMapping("/api/updateAdmin/{adminId}")
	AdminDTO updateAdmin(@PathVariable("adminId") int id,@RequestBody Admin admin)
	{
		return adminService.updateAdmin(id, admin);
	}


}
