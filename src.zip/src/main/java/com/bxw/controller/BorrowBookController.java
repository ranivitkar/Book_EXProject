package com.bxw.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bxw.entities.BorrowBook;
import com.bxw.model.BorrowBookDTO;
import com.bxw.service.BorrowBookService;
import com.bxw.utility.BorrowBookConverter;

@RestController
public class BorrowBookController {
	@Autowired
	BorrowBookService borrowBookService;
	@Autowired
	BorrowBookConverter borrowBookConverter;
	
	@PostMapping("/api/createBorrowBook")
	ResponseEntity<BorrowBookDTO> createBorrowBook(@RequestBody BorrowBookDTO borrowBookDto)
	{
		final BorrowBook borrowBook=borrowBookConverter.convertTOBorrowBookEntity(borrowBookDto);
		return new ResponseEntity<BorrowBookDTO>(borrowBookService.createBorrowBook(borrowBook),HttpStatus.CREATED);
	}
	
	@GetMapping("/api/getAllBorrowBook")
	List<BorrowBookDTO> getAllBorrowBooks()
	{
		return borrowBookService.getAllBorrowBooks();
	}
	
	@GetMapping("/api/getBorrowBookById/{bookId}")
	BorrowBookDTO getBorrowBookById(@PathVariable("bookId") int id)
	{
		return borrowBookService.getBorrowBookById(id);
	}
	
	@DeleteMapping("/api/deleteBorrowBook/{bookId}")
	String deleteBorrowBookByID(@PathVariable("bookId")int id)
	{
		return borrowBookService.deleteBorrowBookById(id);
	}
	
	@PutMapping("/api/updateBorrowBook/{bookId}")
	BorrowBookDTO updateBorrowBook(@PathVariable("bookId") int id, @RequestBody BorrowBook borrowBook)
	{
		return borrowBookService.updateBorrowBook(id, borrowBook);
	}


}
