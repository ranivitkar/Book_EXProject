package com.bxw.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bxw.entities.Book;
import com.bxw.model.BookDTO;
import com.bxw.service.BookService;
import com.bxw.utility.BookConverter;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;


@RestController
public class BookController {
	@Autowired
	BookService bookService;
	
	@Autowired
	BookConverter bookConverter;
	
	@PostMapping("/api/createBook")
	ResponseEntity<BookDTO> createBook(@RequestBody BookDTO bookDto)
	{
		final Book book=bookConverter.convertToBookEntity(bookDto);
		return new ResponseEntity<BookDTO>(bookService.createBook(book),HttpStatus.CREATED);
	}
	
	@GetMapping("/api/getAllBook")
	List<BookDTO> getAllBook()
	{
		return bookService.getAllBook();
	}
	
	@GetMapping("/api/getBookId/{bookId}")
	BookDTO getBookById(@PathVariable("bookId")int id)
	{
		return bookService.getBookById(id);
	}
	
	@DeleteMapping("/api/deleteBook/{bookId}")
	String deleteBookById(@PathVariable("bookId")int id)
	{
		return bookService.deleteBookById(id);
	}
	
	@PutMapping("/api/updateBook/{bookId}")
	BookDTO updateBook(@PathVariable("bookId")int id,@RequestBody Book book)
	{
		return bookService.updateBook(id, book);
	}
	

}
