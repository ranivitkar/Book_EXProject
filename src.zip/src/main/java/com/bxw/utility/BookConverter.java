package com.bxw.utility;

import org.springframework.beans.BeanUtils;

import com.bxw.entities.Book;
import com.bxw.model.BookDTO;

public class BookConverter {
	
	public Book convertToBookEntity(BookDTO bookDTO)
	{
		Book book=new Book();
		if(book!=null)
		{
			BeanUtils.copyProperties(bookDTO, book);
		}
		return book;
	}
	
		
	public BookDTO convertToBookDTO(Book book)
	{
		BookDTO bookDTO=new BookDTO();
		if(book!=null)
		{
			BeanUtils.copyProperties(book, bookDTO);
		}
		return bookDTO;
		
	}
}
