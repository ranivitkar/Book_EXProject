package com.bxw.utility;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.bxw.entities.BorrowBook;
import com.bxw.model.BorrowBookDTO;

@Component
public class BorrowBookConverter {
	public BorrowBook convertTOBorrowBookEntity(BorrowBookDTO borrowBookDTO)
	{
		BorrowBook borrowBook=new BorrowBook();
		if(borrowBook!=null)
		{
			BeanUtils.copyProperties(borrowBookDTO, borrowBook);
		}
		return borrowBook;
	}
	
	public BorrowBookDTO convertToBorrowBookDTO(BorrowBook borrowBook)
	{
		BorrowBookDTO borrowBookDTO=new BorrowBookDTO();
		if(borrowBook!=null)
		{
			BeanUtils.copyProperties(borrowBook, borrowBookDTO);
		}
		return borrowBookDTO;
	}

}
