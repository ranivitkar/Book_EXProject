package com.bxw.utility;

import org.springframework.beans.BeanUtils;

import com.bxw.entities.Admin;
import com.bxw.entities.Owner;
import com.bxw.model.AdminDTO;
import com.bxw.model.OwnerDTO;

public class OwnerConverter {
	public Admin convertToAdminEntity(AdminDTO adminDTO)
	{
		Admin admin=new Admin();
		if(admin!=null)
		{
			BeanUtils.copyProperties(adminDTO, admin);
		}
		return admin;
	}
	
	public AdminDTO convertToAdminDTO(Admin admin)
	{
		AdminDTO adminDTO=new AdminDTO();
		if(admin!=null)
		{
			BeanUtils.copyProperties(admin, adminDTO);
		}
		return adminDTO;
	}
	
	public Owner convertToOwnerEntity(OwnerDTO ownerDto)
	{
		Owner owner=new Owner();
		if(owner!=null)
		{
			BeanUtils.copyProperties(ownerDto, owner);
		}
		return owner;
	}
	
	public OwnerDTO convertToOwnerDTO(Owner owner)
	{
		OwnerDTO ownerDTO=new OwnerDTO();
		if(owner!=null)
		{
			BeanUtils.copyProperties(owner, ownerDTO);
		}
		return ownerDTO;
	}

}
