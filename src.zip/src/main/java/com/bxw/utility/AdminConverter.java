package com.bxw.utility;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.bxw.entities.Admin;
import com.bxw.model.AdminDTO;

@Component
public class AdminConverter {
	public Admin convertToAdminEntity(AdminDTO adminDTO)
	{
		Admin admin=new Admin();
		if(admin!=null)
		{
			BeanUtils.copyProperties(adminDTO, admin);
		}
		return admin;
	}
	
	public AdminDTO convertToAdminDTO(Admin admin)
	{
		AdminDTO adminDTO=new AdminDTO();
		if(admin!=null)
		{
			BeanUtils.copyProperties(admin, adminDTO);
		}
		return adminDTO;
	}
}
