package com.bxw.utility;

import org.springframework.beans.BeanUtils;

import com.bxw.entities.Category;
import com.bxw.model.CategoryDTO;

public class CategoryConverter {

	
	public Category convertToCategoryEntity(CategoryDTO categoryDTO)
	{
		Category category=new Category();
		if(category!=null)
		{
			BeanUtils.copyProperties(categoryDTO, category);
		}
		return category;
	}
	
	public CategoryDTO convertToCategoryDTO(Category category)
	{
		CategoryDTO categoryDTO=new CategoryDTO();
		if(category!=null)
		{
			BeanUtils.copyProperties(category, categoryDTO);
		}
		return categoryDTO;
			
	}

}
