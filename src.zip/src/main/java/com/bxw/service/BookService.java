package com.bxw.service;

import java.util.List;

import com.bxw.entities.Book;
import com.bxw.model.BookDTO;

public interface BookService {
	
	BookDTO createBook(Book book);
	List<BookDTO> getAllBook();
	BookDTO getBookById(int id);
	String deleteBookById(int id);
	BookDTO updateBook(int id,Book book);

}
