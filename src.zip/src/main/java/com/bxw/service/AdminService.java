package com.bxw.service;

import java.util.List;

import com.bxw.entities.Admin;
import com.bxw.model.AdminDTO;

public interface AdminService {
	AdminDTO createAdmin(Admin admin);
	List<AdminDTO> getAllAdmin();
	AdminDTO getAdminById(int id);
	String deleteAdminById(int id);
	AdminDTO updateAdmin(int id, Admin admin);
}
