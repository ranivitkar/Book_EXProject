package com.bxw.service;

import java.util.List;

import com.bxw.entities.User;
import com.bxw.model.UserDTO;

public interface UserService {
	
	UserDTO createUser(User user);
	List<UserDTO> getAllUsers();
	UserDTO getUserById(int id);
	String deleteUserById(int id);
	UserDTO updateUser(int id,User user);
	
}
