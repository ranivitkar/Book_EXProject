package com.bxw.service;

import java.util.List;

import com.bxw.entities.Category;
import com.bxw.model.CategoryDTO;

public interface CategoryService {
	CategoryDTO createCategory(Category category);
	List<CategoryDTO> getAllCategory();
	CategoryDTO getCategoryById(int id);
	String deleteCategoryById(int id);
	CategoryDTO updateCategory(int id, Category category);

}
