package com.bxw.service;

import java.util.List;

import com.bxw.entities.Owner;
import com.bxw.model.OwnerDTO;

public interface OwnerService {
	OwnerDTO createOwner(Owner owner);
	List<OwnerDTO> getAllOwner();
	OwnerDTO getOwnerById(int id);
	String deleteOwnerById(int id);
	OwnerDTO updateOwner(int id, Owner owner);

}
