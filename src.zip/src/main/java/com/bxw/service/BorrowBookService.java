package com.bxw.service;

import java.util.List;

import com.bxw.entities.BorrowBook;
import com.bxw.model.BorrowBookDTO;

public interface BorrowBookService {
	BorrowBookDTO createBorrowBook(BorrowBook borrowBook);
	List<BorrowBookDTO> getAllBorrowBooks();
	BorrowBookDTO getBorrowBookById(int id);
	String deleteBorrowBookById(int id);
	BorrowBookDTO updateBorrowBook(int id,BorrowBook borrowBook);

}
