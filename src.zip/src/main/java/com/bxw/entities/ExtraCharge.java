package com.bxw.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class ExtraCharge {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int userId;
	private double charges;
	private int bookId;
	public ExtraCharge() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ExtraCharge(int userId, double charges, int bookId) {
		super();
		this.userId = userId;
		this.charges = charges;
		this.bookId = bookId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public double getCharges() {
		return charges;
	}
	public void setCharges(double charges) {
		this.charges = charges;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	
}
