package com.bxw.entities;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Payment {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int ownerId;
	private double amount;
	private int userId;
	private int bookId;
	private Date date=new Date();
	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Payment(int ownerId, double amount, int userId, int bookId, Date date) {
		super();
		this.ownerId = ownerId;
		this.amount = amount;
		this.userId = userId;
		this.bookId = bookId;
		this.date = date;
	}
	public int getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
}
