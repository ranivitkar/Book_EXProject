package com.bxw.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity

public class Owner {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int ownerId;
	private String ownerName;
	private String email;
	private String password;
	private int contactNo;
	private String ownerAddress;
	public int getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getContactNo() {
		return contactNo;
	}
	public void setContactNo(int contactNo) {
		this.contactNo = contactNo;
	}
	public String getOwnerAddress() {
		return ownerAddress;
	}
	public void setOwnerAddress(String ownerAddress) {
		this.ownerAddress = ownerAddress;
	}
	public Owner(int ownerId, String ownerName, String email, String password, int contactNo, String ownerAddress) {
		super();
		this.ownerId = ownerId;
		this.ownerName = ownerName;
		this.email = email;
		this.password = password;
		this.contactNo = contactNo;
		this.ownerAddress = ownerAddress;
	}
	public Owner() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
