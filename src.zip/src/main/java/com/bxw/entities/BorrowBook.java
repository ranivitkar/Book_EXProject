package com.bxw.entities;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


@Entity
public class BorrowBook {
	private int user_id;
	private String bookName;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int bookId;
	private float price;
	private Date returnDate=new Date();
	private int ownerId;
	private Date issuedate=new Date();
	public BorrowBook() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BorrowBook(int user_id, String bookName, int bookId, float price, Date returnDate, int ownerId,
			Date issuedate) {
		super();
		this.user_id = user_id;
		this.bookName = bookName;
		this.bookId = bookId;
		this.price = price;
		this.returnDate = returnDate;
		this.ownerId = ownerId;
		this.issuedate = issuedate;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public Date getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}
	public int getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}
	public Date getIssuedate() {
		return issuedate;
	}
	public void setIssuedate(Date issuedate) {
		this.issuedate = issuedate;
	}
	
}
