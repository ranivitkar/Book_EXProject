package com.bxw.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bxw.entities.Category;
import com.bxw.model.CategoryDTO;
import com.bxw.repository.CategoryRepository;
import com.bxw.service.CategoryService;
import com.bxw.utility.CategoryConverter;

@Service
public class CategoryServiceImpl implements CategoryService{
	@Autowired
	CategoryRepository categoryRepository;
	
	@Autowired
	CategoryConverter categoryConverter;

	@Override
	public CategoryDTO createCategory(Category category) {
		// TODO Auto-generated method stub
		Category category1=categoryRepository.save(category);
		return categoryConverter.convertToCategoryDTO(category1);
	}

	@Override
	public List<CategoryDTO> getAllCategory() {
		// TODO Auto-generated method stub
		List<Category> categories=categoryRepository.findAll();
		List<CategoryDTO> dtos=new ArrayList<>();
		for(Category c:categories)
		{
			dtos.add(categoryConverter.convertToCategoryDTO(c));
		}
		return dtos;
	}

	@Override
	public CategoryDTO getCategoryById(int id) {
		// TODO Auto-generated method stub
		Category category=categoryRepository.findById(id).get();
		return categoryConverter.convertToCategoryDTO(category);
	}

	@Override
	public String deleteCategoryById(int id) {
		// TODO Auto-generated method stub
	 categoryRepository.deleteById(id);
	 return "Category Deleted Succeccfully";
	}

	@Override
	public CategoryDTO updateCategory(int id, Category category) {
		// TODO Auto-generated method stub
		Category c=categoryRepository.findById(id).get();
		c.setCategoryName(category.getCategoryName());
		Category cat=categoryRepository.save(c);
		return categoryConverter.convertToCategoryDTO(cat);
	}

	

}
