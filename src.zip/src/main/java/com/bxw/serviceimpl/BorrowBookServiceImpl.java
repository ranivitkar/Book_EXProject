package com.bxw.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bxw.entities.BorrowBook;
import com.bxw.model.BorrowBookDTO;
import com.bxw.repository.BorrowBookRepository;
import com.bxw.service.BorrowBookService;
import com.bxw.utility.BorrowBookConverter;

@Service
public class BorrowBookServiceImpl implements BorrowBookService{
	@Autowired
	BorrowBookRepository borrowBookRepository;
	
	@Autowired
	BorrowBookConverter borrowBookConverter;
	
	@Override
	public BorrowBookDTO createBorrowBook(BorrowBook borrowBook) {
		// TODO Auto-generated method stub
		BorrowBook borrowbook=borrowBookRepository.save(borrowBook);
		return borrowBookConverter.convertToBorrowBookDTO(borrowbook);
	}

	@Override
	public List<BorrowBookDTO> getAllBorrowBooks() {
		// TODO Auto-generated method stub
		List<BorrowBook> borrowBooks=borrowBookRepository.findAll();
		List<BorrowBookDTO> dtos=new ArrayList<>();
		for(BorrowBook b:borrowBooks)
		{
			dtos.add(borrowBookConverter.convertToBorrowBookDTO(b));
		}
		return dtos;
	}

	@Override
	public BorrowBookDTO getBorrowBookById(int id) {
		// TODO Auto-generated method stub
		BorrowBook b=borrowBookRepository.findById(id).get();
		return borrowBookConverter.convertToBorrowBookDTO(b);
	}

	@Override
	public String deleteBorrowBookById(int id) {
		// TODO Auto-generated method stub
		 borrowBookRepository.deleteById(id);
		 return "Borrowed Book Deleted";
	}

	@Override
	public BorrowBookDTO updateBorrowBook(int id, BorrowBook borrowBook) {
		// TODO Auto-generated method stub
		BorrowBook bb=borrowBookRepository.findById(id).get();
		bb.setBookName(borrowBook.getBookName());
		bb.setIssuedate(borrowBook.getIssuedate());
		bb.setPrice(borrowBook.getPrice());
		bb.setReturnDate(borrowBook.getReturnDate());
		BorrowBook borrow=borrowBookRepository.save(bb);
		return borrowBookConverter.convertToBorrowBookDTO(borrow);
	}

}
