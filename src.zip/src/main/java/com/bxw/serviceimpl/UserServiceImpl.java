package com.bxw.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bxw.entities.User;
import com.bxw.repository.UserRepository;
import com.bxw.model.UserDTO;
import com.bxw.service.UserService;
import com.bxw.utility.UserConverter;


@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserRepository userRepository;
	@Autowired
	UserConverter converter;
	
	
	@Override
	public UserDTO createUser(User user)
	{
		User user1=userRepository.save(user);
		return converter.convertToUserDTO(user1);
	}
	
	@Override
	public UserDTO getUserById(int id)
	{
		User user2=userRepository.findById(id).get();
		return converter.convertToUserDTO(user2);
	}

	@Override
	public List<UserDTO> getAllUsers() {
		// TODO Auto-generated method stub
		List<User> users=userRepository.findAll();
		List<UserDTO> dtos=new ArrayList<>();
		for(User u:users)
		{
			dtos.add(converter.convertToUserDTO(u));
		}
		return dtos;
	}

	@Override
	public String deleteUserById(int id) {
		// TODO Auto-generated method stub
		userRepository.deleteById(id);
		return "User Deleted ";
	}

	@Override
	public UserDTO updateUser(int id, User user) {
		// TODO Auto-generated method stub
		User u1=userRepository.findById(id).get();
		u1.setUsername(user.getUsername());
		u1.setAddress(user.getAddress());
		u1.setEmail(user.getEmail());
		u1.setPassword(user.getPassword());
		u1.setJoin_date(user.getJoin_date());
		
		User user3=userRepository.save(u1);
		return converter.convertToUserDTO(user3);
	}
	
}
