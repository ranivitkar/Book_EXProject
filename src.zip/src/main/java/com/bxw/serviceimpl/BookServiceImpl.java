package com.bxw.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bxw.entities.Book;
import com.bxw.model.BookDTO;
import com.bxw.repository.BookRepository;
import com.bxw.service.BookService;
import com.bxw.utility.BookConverter;

@Service
public class BookServiceImpl implements BookService{
	@Autowired
	BookRepository bookRepository;
	
	@Autowired
	BookConverter bookConverter;

	@Override
	public BookDTO createBook(Book book) {
		// TODO Auto-generated method stub
		Book book1=bookRepository.save(book);
		return bookConverter.convertToBookDTO(book1);
	}

	@Override
	public List<BookDTO> getAllBook() {
		// TODO Auto-generated method stub
		List<Book> books=bookRepository.findAll();
		List<BookDTO> dtos=new ArrayList<>();
		for(Book b:books)
		{
			dtos.add(bookConverter.convertToBookDTO(b));
		}
		return dtos;
	}

	@Override
	public BookDTO getBookById(int id) {
		// TODO Auto-generated method stub
		Book book=bookRepository.findById(id).get();
		return bookConverter.convertToBookDTO(book);
	}

	@Override
	public String deleteBookById(int id) {
		// TODO Auto-generated method stub
		bookRepository.deleteById(id);
		return "Book Deleted Successfully";
	}

	@Override
	public BookDTO updateBook(int id, Book book) {
		// TODO Auto-generated method stub
		Book bk=bookRepository.findById(id).get();
		bk.setAuthorName(book.getAuthorName());
		bk.setBookName(book.getBookName());
		bk.setCategoryId(book.getCategoryId());
		bk.setPrice(book.getPrice());
		bk.setOwnerId(book.getOwnerId());
		return bookConverter.convertToBookDTO(bk);
	}
	
	

}
