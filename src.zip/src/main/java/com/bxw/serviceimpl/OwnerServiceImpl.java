package com.bxw.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bxw.entities.Owner;
import com.bxw.model.OwnerDTO;
import com.bxw.repository.OwnerRepository;
import com.bxw.service.OwnerService;
import com.bxw.utility.OwnerConverter;

@Service
public class OwnerServiceImpl implements OwnerService{	
	@Autowired
	OwnerRepository ownerRepository;
	
	@Autowired
	OwnerConverter ownerConverter;

	@Override
	public OwnerDTO createOwner(Owner owner) {
		// TODO Auto-generated method stub
		Owner owner1=ownerRepository.save(owner);
		return ownerConverter.convertToOwnerDTO(owner1);
	}

	@Override
	public List<OwnerDTO> getAllOwner() {
		// TODO Auto-generated method stub
		List<Owner> owners=ownerRepository.findAll();
		List<OwnerDTO> dtos=new ArrayList<>();
		for(Owner o:owners)
		{
			dtos.add(ownerConverter.convertToOwnerDTO(o));
		}
		return dtos;
	}

	@Override
	public OwnerDTO getOwnerById(int id) {
		// TODO Auto-generated method stub
		
		Owner o=ownerRepository.findById(id).get();
		return ownerConverter.convertToOwnerDTO(o);
	}

	@Override
	public String deleteOwnerById(int id) {
		// TODO Auto-generated method stub
		ownerRepository.deleteById(id);
		return "Owner Deleted Successfully";
	}

	@Override
	public OwnerDTO updateOwner(int id, Owner owner) {
		// TODO Auto-generated method stub
		Owner o=ownerRepository.findById(id).get();
		o.setOwnerName(owner.getOwnerName());
		o.setEmail(owner.getEmail());
		o.setPassword(owner.getPassword());
		o.setContactNo(owner.getContactNo());
		o.setOwnerAddress(owner.getOwnerAddress());
		Owner ow=ownerRepository.save(o);
		return ownerConverter.convertToOwnerDTO(ow);
	}
	
	
}
