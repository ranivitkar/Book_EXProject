
package com.bxw.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bxw.entities.Admin;
import com.bxw.model.AdminDTO;
import com.bxw.repository.AdminRepository;
import com.bxw.service.AdminService;
import com.bxw.utility.AdminConverter;

@Service
public class AdminServiceImpl implements AdminService{
	@Autowired
	AdminRepository adminRepository;
	
	@Autowired
	AdminConverter adminConverter;

	@Override
	public AdminDTO createAdmin(Admin admin) {
		// TODO Auto-generated method stub
		Admin admin1=adminRepository.save(admin);
		return adminConverter.convertToAdminDTO(admin1);
	}

	@Override
	public List<AdminDTO> getAllAdmin() {
		// TODO Auto-generated method stub
		
		List<Admin> admins=adminRepository.findAll();
		List<AdminDTO> dtos=new ArrayList<>();
		for(Admin a:admins)
		{
			dtos.add(adminConverter.convertToAdminDTO(a));
		}
		return dtos;
	}

	@Override
	public AdminDTO getAdminById(int id) {
		// TODO Auto-generated method stub
		
		Admin ad=adminRepository.findById(id).get();
		return adminConverter.convertToAdminDTO(ad);
		
	}

	@Override
	public String deleteAdminById(int id) {
		// TODO Auto-generated method stub
		adminRepository.deleteById(id);
		return "Admin Deleted Successfully";
	}

	@Override
	public AdminDTO updateAdmin(int id, Admin admin) {
		// TODO Auto-generated method stub
		Admin ad=adminRepository.findById(id).get();
		ad.setUsername(admin.getUsername());
		ad.setEmail(admin.getEmail());
		ad.setPassword(admin.getPassword());
		Admin adm=adminRepository.save(ad);
		return adminConverter.convertToAdminDTO(adm);
	}

}
