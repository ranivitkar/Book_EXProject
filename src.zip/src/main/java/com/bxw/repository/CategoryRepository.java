package com.bxw.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bxw.entities.Category;

public interface CategoryRepository extends JpaRepository<Category,Integer> {

}
