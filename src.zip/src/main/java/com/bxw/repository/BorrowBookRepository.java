package com.bxw.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bxw.entities.BorrowBook;

public interface BorrowBookRepository extends JpaRepository<BorrowBook,Integer>{

}
