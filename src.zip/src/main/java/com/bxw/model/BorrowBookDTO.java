package com.bxw.model;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BorrowBookDTO {
	private int user_id;
	private String bookName;
	private int bookId;
	private float price;
	private Date returnDate=new Date();
	private int ownerId;
	private Date issuedate=new Date();

}
