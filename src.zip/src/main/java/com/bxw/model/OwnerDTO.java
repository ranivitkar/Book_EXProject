package com.bxw.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OwnerDTO {
	private int ownerId;
	private String ownerName;
	private String email;
	private String password;
	private int contactNo;
	private String ownerAddress;

}
