package com.bxw.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CategoryDTO {
	private int categoryId;
	private String categoryName;
}
