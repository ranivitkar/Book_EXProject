package com.bxw.model;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserDTO {
	private int user_id;
	private String username;
	private String email;
	private String password;
	private String address;
	private Date join_date=new Date();
}
