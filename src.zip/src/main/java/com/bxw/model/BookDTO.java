package com.bxw.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BookDTO {
	private int bookId;
	private int categoryId;
	private int ownerId;
	private String bookName;
	private String authorName;
}
