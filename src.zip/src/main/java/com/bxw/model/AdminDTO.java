package com.bxw.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdminDTO {
	private int adminId;
	private String username;
	private String email;
	private String password;

}
