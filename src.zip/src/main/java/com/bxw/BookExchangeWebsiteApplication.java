package com.bxw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.bxw.entities.Owner;
import com.bxw.entities.User;

@SpringBootApplication
public class BookExchangeWebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookExchangeWebsiteApplication.class, args);
		System.out.println("Book Exchange Website");
	}
}
